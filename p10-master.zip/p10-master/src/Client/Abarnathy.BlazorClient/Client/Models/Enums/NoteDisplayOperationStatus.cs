﻿// ReSharper disable InconsistentNaming
namespace Abarnathy.BlazorClient.Client.Models
{
    public enum NoteDisplayOperationStatus
    {
        Initial = 0,
        GET,
        GET_Success,
        GET_Error,
    }
}