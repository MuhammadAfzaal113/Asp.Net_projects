namespace Abarnathy.BlazorClient.Client.Models
{
    public enum ComponentMode
    {
        Create,
        Edit
    }
}