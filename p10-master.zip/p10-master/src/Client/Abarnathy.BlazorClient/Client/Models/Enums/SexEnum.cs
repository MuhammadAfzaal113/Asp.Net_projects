namespace Abarnathy.BlazorClient.Client.Models
{
    public enum SexEnum
    {
        Default = 0,
        Male = 1,
        Female = 2
    }
}