namespace Abarnathy.BlazorClient.Client.Models
{
    public enum PatientsAllOperationStatusEnum
    {
        Initial,
        Pending,
        Success,
        Error
    }
}