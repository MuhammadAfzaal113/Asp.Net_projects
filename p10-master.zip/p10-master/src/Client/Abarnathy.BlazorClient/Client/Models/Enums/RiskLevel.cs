namespace Abarnathy.BlazorClient.Client.Models
{
    public enum RiskLevel
    {
        None,
        Borderline,
        InDanger,
        EarlyOnset
    }
}