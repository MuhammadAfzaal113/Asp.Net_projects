using System;

namespace Abarnathy.BlazorClient.Client.Models
{
    public class AssessmentResult
    {
        public RiskLevel RiskLevel { get; set; }
        public DateTime TimeCreated { get; set; }
    }
}