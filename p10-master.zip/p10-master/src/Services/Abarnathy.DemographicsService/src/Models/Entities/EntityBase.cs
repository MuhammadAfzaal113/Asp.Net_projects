namespace Abarnathy.DemographicsService.Models
{
    /// <summary>
    /// Facilitates entity constraint on RepositoryBase.
    /// </summary>
    public class EntityBase
    {
        public int Id { get; set; }
    }
}