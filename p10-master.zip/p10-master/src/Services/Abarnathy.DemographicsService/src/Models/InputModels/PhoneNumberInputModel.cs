namespace Abarnathy.DemographicsService.Models
{
    public class PhoneNumberInputModel
    {
        public int Id { get; set; }
        public string Number { get; set; }
    }
}