namespace Abarnathy.AssessmentService.Models
{
    public enum RiskLevel
    {
        None,
        Borderline,
        InDanger,
        EarlyOnset
    }
}