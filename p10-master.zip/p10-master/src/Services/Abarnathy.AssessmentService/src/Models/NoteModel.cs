namespace Abarnathy.AssessmentService.Models
{
    public class NoteModel
    {
        public int PatientId { get; set; }
        public string Content { get; set; }
    }
}