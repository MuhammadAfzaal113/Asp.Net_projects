using System;

namespace Abarnathy.AssessmentService.Models
{
    public class PatientModel
    {
        public int Id { get; set; }
        public DateTime DateOfBirth { get; set; }

        public int SexId { get; set; }
        
    }
}